<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2021 SIRS <a href="https://rsupsurakarta.co.id" target="new_tab">RSUP
            Surakarta</a>.</strong> All rights
    reserved.
</footer>
