<html lang="en">

<head>
    <title>Pencarian Autocomplete di Laravel Menggunakan Ajax</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
</head>

<body>

    <div class="container">
        <h2>Pencarian Autocomplete di Laravel Menggunakan Ajax</h2>
        <br />
        <select class="cari form-control" style="width:500px;" name="cari"></select>
    </div>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script type="text/javascript">
        $('.cari').select2({
            placeholder: 'Cari...',
            ajax: {
                url: '/geticd10',
                dataType: 'json',
                delay: 250,
                processResults: function(data) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                text: item.nama_penyakit,
                                id: item.kd_penyakit
                            }
                        })
                    };
                },
                cache: true
            }
        });
    </script>
</body>

</html>
