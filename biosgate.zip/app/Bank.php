<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bank extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'kd_bank', 'nama', 'norek'
    ];

    public function SaldoKeuangan()
    {
        return $this->hasMany('App\SaldoKeuangan');
    }
}
